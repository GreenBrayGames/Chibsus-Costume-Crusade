﻿using UnityEngine;
using System.Collections;

public class GlobalEnum : MonoBehaviour {
	//Used to create and store enumerations we create so we can
	//reference it with only one source. This will keep
	//data consistant throughout the code

	public enum PlayerControllerType {Keyboard1, Keyboard2,
		Controller1, Controller2, Controller3, Controller4, Empty};

	//expands as new tiles are entered
	public enum TileType {Dirt, Grass, Ice, Magma, RockWall, StonePath, Water};
}
