﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileScript : MonoBehaviour {

	//public
	public int TileNumberHorizontal;
	public int TileNumberVertical;
	public GlobalEnum.TileType type; 

	//private 
	public GameObject[] adjacentTiles = new GameObject[4]; //tiles go (clockwise) from top, right, bottom, left 
	private bool tileWalkable = true;
	private float tileSize = 2.5f;
	// Use this for initialization
	void Start () {
		SetAdjacentTiles ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void SetupTile(GlobalEnum.TileType newType, int tileXNum, int tileYNum)
	{
		type = newType;//GUNDAAAAAAAAAAAMM
		TileNumberHorizontal = tileXNum;
		TileNumberVertical = tileYNum;
	}

	public Vector2 GetTileNumber()
	{
		return new Vector2 (TileNumberHorizontal, TileNumberVertical);
	}

	void SetAdjacentTiles()
	{
		adjacentTiles[0] = GameObject.Find((TileNumberHorizontal).ToString() + "," + (TileNumberVertical - 1).ToString());
		adjacentTiles[1] = GameObject.Find((TileNumberHorizontal - 1).ToString() + "," + (TileNumberVertical).ToString());
		adjacentTiles[2] = GameObject.Find((TileNumberHorizontal).ToString() + "," + (TileNumberVertical + 1).ToString());
		adjacentTiles[3] = GameObject.Find((TileNumberHorizontal + 1).ToString() + "," + (TileNumberVertical).ToString());
	}
}
