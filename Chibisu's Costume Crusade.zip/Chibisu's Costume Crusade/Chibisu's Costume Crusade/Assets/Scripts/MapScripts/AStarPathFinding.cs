﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AStarPathFinding : MonoBehaviour {

	//private 
	List<GameObject> openNodeList; //tiles being considered for closed list
	List<GameObject> closedNodeList; //tiles being considered for final path
 	List<GameObject> FinalPath; //path to return as the final
	
	bool isCalculating = true;

	GameObject startingTile;
	GameObject targetTile;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void StopCalculating()
	{
		isCalculating = false;
	}

	void StartCalculating()
	{
		isCalculating = true;
	}

	void FindPath()
	{
		openNodeList.Clear ();
		closedNodeList.Clear ();
		closedNodeList.Add = startingTile;
	}
}
