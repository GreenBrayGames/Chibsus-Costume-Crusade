﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using System.IO;  

public class MapReaderScript : MonoBehaviour {
	
	public string mapFile = "map1.lvl";

	private string filePathGeneral = "Assets/Resources/";
	private string filePathMaps = "Maps/";
	private string filePathPrefabs = "Prefabs/";
	private string filePathTiles = "Art/Tiles/";
	// Use this for initialization
	void Start () {
		LoadFile (filePathGeneral + filePathMaps + mapFile);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private void LoadFile(string file_path)
	{
		StreamReader streamReader = new StreamReader(file_path);

		int lineCount = 0; //used to count how many lines processed
		string[] charactersArray = new string[0];
		float tileHeight = 0;
		float tileWidth = 0;
		while(!streamReader.EndOfStream)
		{
			
			string line = streamReader.ReadLine ();
			// Do Something with the input. 
			charactersArray = line.Split(","[0]);
			for (int i = 0; i < charactersArray.Length; i++)
			{
				GameObject tileToAdd = Instantiate(Resources.Load(filePathPrefabs + "MapTile")) as GameObject;

				tileHeight = tileToAdd.GetComponent<SpriteRenderer> ().bounds.size.y * -1;
				tileWidth = tileToAdd.GetComponent<SpriteRenderer> ().bounds.size.x;
				tileToAdd.transform.position = new Vector3 (i * tileWidth, lineCount * tileHeight, 0);
				tileToAdd.transform.parent = GameObject.Find ("Map").transform;

				if (charactersArray [i].ToString() == "d")
				{
					tileToAdd.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite>(filePathTiles + "DirtTile");
					tileToAdd.name = i + "," + lineCount;
					tileToAdd.GetComponent<TileScript> ().SetupTile (GlobalEnum.TileType.Dirt, i, lineCount);
				}
				else if (charactersArray [i].ToString() == "g")
				{
					tileToAdd.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite>(filePathTiles + "GrassTile");
					tileToAdd.name = i + "," + lineCount;
					tileToAdd.GetComponent<TileScript> ().SetupTile (GlobalEnum.TileType.Grass, i, lineCount);
				}
				else if (charactersArray [i].ToString() == "i")
				{
					tileToAdd.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite>(filePathTiles + "IceTile");
					tileToAdd.name = i + "," + lineCount;
					tileToAdd.GetComponent<TileScript> ().SetupTile (GlobalEnum.TileType.Ice, i, lineCount);
				}
				else if (charactersArray [i].ToString() == "m")
				{
					tileToAdd.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite>(filePathTiles + "MagmaTile");
					tileToAdd.name = i + "," + lineCount;
					tileToAdd.GetComponent<TileScript> ().SetupTile (GlobalEnum.TileType.Magma, i, lineCount);
				}
				else if (charactersArray [i].ToString() == "s")
				{
					tileToAdd.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite>(filePathTiles + "StoneTile");
					tileToAdd.name = i + "," + lineCount;
					tileToAdd.GetComponent<TileScript> ().SetupTile (GlobalEnum.TileType.StonePath, i, lineCount);
				}
				else if (charactersArray [i].ToString() == "w")
				{
					tileToAdd.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite>(filePathTiles + "WaterTile");
					tileToAdd.name = i + "," + lineCount;
					tileToAdd.GetComponent<TileScript> ().SetupTile (GlobalEnum.TileType.Water, i, lineCount);
				}


			}
			lineCount++;

		}
		streamReader.Close( ); 
		GameObject.Find ("Map").transform.Translate (new Vector3(charactersArray.Length * tileWidth / 2, lineCount * tileHeight / 2, 0) * -1);
	}
}

