﻿using UnityEngine;
using System.Collections;

public class ControllerProfileScript : MonoBehaviour {

	//current keys
	KeyCode currentKeyboardMoveLeftKey;
	KeyCode currentKeyboardMoveRightKey;
	KeyCode currentKeyboardMoveUpKey;
	KeyCode currentKeyboardMoveDownKey;
	KeyCode currentKeyboardAbility1Key;
	KeyCode currentKeyboardAbility2Key;
	KeyCode currentKeyboardAbility3Key;
	KeyCode currentKeyboardAbility4Key;

	//current controller
	string  currentControllerMoveXAxis;
	string  currentControllerMoveYAxis;
	KeyCode currentControllerAbility1;
	KeyCode currentControllerAbility2;
	KeyCode currentControllerAbility3;
	KeyCode currentControllerAbility4;


	//player 1 keyboard
	KeyCode Keyboard1MoveLeftKey		= KeyCode.A;
	KeyCode Keyboard1MoveRightKey		= KeyCode.D;
	KeyCode Keyboard1MoveUpKey			= KeyCode.W;
	KeyCode Keyboard1MoveDownKey		= KeyCode.S;		
	KeyCode Keyboard1Ability1Key		= KeyCode.Alpha1;
	KeyCode Keyboard1Ability2Key		= KeyCode.Alpha2;
	KeyCode Keyboard1Ability3Key		= KeyCode.Alpha3;
	KeyCode Keyboard1Ability4Key		= KeyCode.Alpha4;

	//player 2 keyboard
	KeyCode Keyboard2MoveLeftKey		= KeyCode.LeftArrow;
	KeyCode Keyboard2MoveRightKey   	= KeyCode.RightArrow;
	KeyCode Keyboard2MoveUpKey     		= KeyCode.UpArrow;
	KeyCode Keyboard2MoveDownKey   		= KeyCode.DownArrow;	
	KeyCode Keyboard2Ability1Key    	= KeyCode.Keypad1;
	KeyCode Keyboard2Ability2Key    	= KeyCode.Keypad2;
	KeyCode Keyboard2Ability3Key    	= KeyCode.Keypad3;
	KeyCode Keyboard2Ability4Key    	= KeyCode.Keypad4;

	//controller 1		 
	string  controller1MoveXAxis		 = "Horizontal1";
	string  controller1MoveYAxis		 = "Vertical1";
	KeyCode controller1Ability1			 = KeyCode.Joystick1Button0;
	KeyCode controller1Ability2 	     = KeyCode.Joystick1Button1;
	KeyCode controller1Ability3 	 	 = KeyCode.Joystick1Button2;
	KeyCode controller1Ability4 	 	 = KeyCode.Joystick1Button3;

	//controller 2
	string  controller2MoveXAxis		 = "Horizontal2";
	string  controller2MoveYAxis		 = "Vertical2";
	KeyCode controller2Ability1			 = KeyCode.Joystick2Button0;
	KeyCode controller2Ability2 	     = KeyCode.Joystick2Button1;
	KeyCode controller2Ability3 	 	 = KeyCode.Joystick2Button2;
	KeyCode controller2Ability4 	 	 = KeyCode.Joystick2Button3;

	//controller 3
	string  controller3MoveXAxis		 = "Horizontal3";
	string  controller3MoveYAxis		 = "Vertical3";
	KeyCode controller3Ability1			 = KeyCode.Joystick3Button0;
	KeyCode controller3Ability2 	     = KeyCode.Joystick3Button1;
	KeyCode controller3Ability3 	 	 = KeyCode.Joystick3Button2;
	KeyCode controller3Ability4 	 	 = KeyCode.Joystick3Button3;

	//controller 4
	string  controller4MoveXAxis		 = "Horizontal4";
	string  controller4MoveYAxis		 = "Vertical4";
	KeyCode controller4Ability1			 = KeyCode.Joystick4Button0;
	KeyCode controller4Ability2 	     = KeyCode.Joystick4Button1;
	KeyCode controller4Ability3 	 	 = KeyCode.Joystick4Button2;
	KeyCode controller4Ability4 	 	 = KeyCode.Joystick4Button3;


	[SerializeField] private float buttonTol = 0.01f; // used so that controllers have dead zone with sticks.
	[SerializeField] private float stickTol = 0.77f;
	private bool facingRight = true;

	[Header("Movement")]
	[SerializeField]private float moveSpeed = 7;

	private Rigidbody2D rigidBody;
	private float H; // used to store horizontal input values.
	private float V; // used to store vertical input values.

	private Vector3 lastPosition = Vector3.zero;

	//player stuff
	PlayerScript player;

	#region StartAndUpdate
	// Use this for initialization
	void Start ()
	{
		player = this.gameObject.GetComponent<PlayerScript>();
		rigidBody = this.gameObject.GetComponent<Rigidbody2D>();
		SetControllerType (player.controllerType);
	}
		
	void Update()
	{
		
	}

	void FixedUpdate()
	{
		UpdateInputs ();
	}

	public void UpdateInputs ()
	{
		UpdateController ();
		UpdateKeyboard ();
	}
	#endregion

	#region Controller
	//=======Controller Functions===================

	void UpdateController()
	{
		MovementControllers ();
	}

	void MovementControllers(){
		if (currentControllerMoveXAxis != null && currentControllerMoveXAxis != "") 
		{
			H = Input.GetAxis (currentControllerMoveXAxis);

			// Checks to see if we push a key / stick, then moves
			if (Mathf.Abs (H) > stickTol) 
			{
				rigidBody.velocity += new Vector2 (H * moveSpeed, rigidBody.velocity.y);
			}
		}
		if (currentControllerMoveYAxis != null && currentControllerMoveYAxis != "") 
		{
			V = Input.GetAxis (currentControllerMoveYAxis);

			// Checks to see if we push a key / stick, then moves
			if (Mathf.Abs (V) > stickTol)
			{
				rigidBody.velocity += new Vector2 (rigidBody.velocity.x, V * moveSpeed);
			}
		}
	}

	#endregion


	#region Keyboard
	//=========Keyboard Functions===========	

	void UpdateKeyboard()
	{
		MovementKeyboard();
	}

	void MovementKeyboard()
	{
		int keysPressed = 0;
		Vector2 v = Vector2.zero;
		if(Input.GetKey(currentKeyboardMoveLeftKey))
		{
			v = new Vector2 (-moveSpeed, rigidBody.velocity.y);
			keysPressed++;
		}
		if(Input.GetKey(currentKeyboardMoveRightKey))
		{
			v = new Vector2 (moveSpeed, rigidBody.velocity.y);
			keysPressed++;
		}
		if(Input.GetKey(currentKeyboardMoveUpKey))
		{
			v = new Vector2 (rigidBody.velocity.x, moveSpeed);
			keysPressed++;
		}
		if(Input.GetKey(currentKeyboardMoveDownKey))
		{
			v = new Vector2 (rigidBody.velocity.x, -moveSpeed);
			keysPressed++;
		}

		//check multiple keys pressed
		if(keysPressed == 1)
		{
			rigidBody.velocity = v;
		}
	}
	#endregion

	#region Getters
	public string GetCurrentDirection()
	{
		string s = "n";
		int keysPressed = 0;
		if (Input.GetKey (currentKeyboardMoveLeftKey))
		{
			s = "l";
			keysPressed++;
		}
		else if (Input.GetKey (currentKeyboardMoveRightKey)) 
		{
			s = "r";
			keysPressed++;
		}
		else if (Input.GetKey (currentKeyboardMoveUpKey)) 
		{
			s = "u";
			keysPressed++;
		}
		else if (Input.GetKey (currentKeyboardMoveDownKey)) 
		{
			s = "d";
			keysPressed++;
		}

		//check multiple keys pressed
		if(keysPressed > 1)
		{
			s = "n";
		}

		return s;
	}

	#endregion

	#region Collision
	void OnCollisionEnter2D(Collision2D other){

	}

	#endregion


	#region SetCurrentController
	//==============Player number control setup=============

	public void SetControllerType(GlobalEnum.PlayerControllerType type)
	{
		if (type == GlobalEnum.PlayerControllerType.Controller1)
		{
			SetAsController1 ();
		}
		else if (type == GlobalEnum.PlayerControllerType.Controller2)
		{
			SetAsController2 ();
		} 
		else if (type == GlobalEnum.PlayerControllerType.Controller3) 
		{
			SetAsController3 ();
		} 
		else if (type == GlobalEnum.PlayerControllerType.Controller4)
		{
			SetAsController4 ();
		} 
		else if (type == GlobalEnum.PlayerControllerType.Keyboard1) 
		{
			SetAsKeyboard1 ();
		}
		else if (type == GlobalEnum.PlayerControllerType.Keyboard2) 
		{
			SetAsKeyboard2 ();
		}
	}


	void SetAsKeyboard1()
	{
		currentKeyboardMoveLeftKey 		= Keyboard1MoveLeftKey;		 
		currentKeyboardMoveRightKey 	= Keyboard1MoveRightKey;		 
		currentKeyboardMoveUpKey 		= Keyboard1MoveUpKey;		 
		currentKeyboardMoveDownKey 		= Keyboard1MoveDownKey;	 
		currentKeyboardAbility1Key 		= Keyboard1Ability1Key;
		currentKeyboardAbility2Key 		= Keyboard1Ability2Key;
		currentKeyboardAbility3Key	 	= Keyboard1Ability3Key;
		currentKeyboardAbility4Key 		= Keyboard1Ability4Key;


		currentControllerMoveXAxis		= "";
		currentControllerMoveYAxis		= "";
		currentControllerAbility1 		= KeyCode.None;
		currentControllerAbility2 		= KeyCode.None;
		currentControllerAbility3 		= KeyCode.None;
		currentControllerAbility4 		= KeyCode.None;

	}

	void SetAsKeyboard2()
	{
		currentKeyboardMoveLeftKey 		= Keyboard2MoveLeftKey;		 
		currentKeyboardMoveRightKey 	= Keyboard2MoveRightKey;		 
		currentKeyboardMoveUpKey 		= Keyboard2MoveUpKey;		 
		currentKeyboardMoveDownKey 		= Keyboard2MoveDownKey;	 
		currentKeyboardAbility1Key 		= Keyboard2Ability1Key;
		currentKeyboardAbility2Key 		= Keyboard2Ability2Key;
		currentKeyboardAbility3Key	 	= Keyboard2Ability3Key;
		currentKeyboardAbility4Key 		= Keyboard2Ability4Key;


		currentControllerMoveXAxis		= "";
		currentControllerMoveYAxis		= "";
		currentControllerAbility1 		= KeyCode.None;
		currentControllerAbility2 		= KeyCode.None;
		currentControllerAbility3 		= KeyCode.None;
		currentControllerAbility4 		= KeyCode.None;
	}

	void SetAsController1()
	{
		currentKeyboardMoveLeftKey 		= KeyCode.None;		 
		currentKeyboardMoveRightKey 	= KeyCode.None;	 
		currentKeyboardMoveUpKey 		= KeyCode.None;		 
		currentKeyboardMoveDownKey 		= KeyCode.None;	 
		currentKeyboardAbility1Key 		= KeyCode.None;
		currentKeyboardAbility2Key 		= KeyCode.None;
		currentKeyboardAbility3Key	 	= KeyCode.None;
		currentKeyboardAbility4Key 		= KeyCode.None;


		currentControllerMoveXAxis		= controller1MoveXAxis;
		currentControllerMoveYAxis		= controller1MoveYAxis;
		currentControllerAbility1 		= controller1Ability1;
		currentControllerAbility2 		= controller1Ability2;
		currentControllerAbility3 		= controller1Ability3;
		currentControllerAbility4 		= controller1Ability4;
	}

	void SetAsController2()
	{
		currentKeyboardMoveLeftKey 		= KeyCode.None;		 
		currentKeyboardMoveRightKey 	= KeyCode.None;	 
		currentKeyboardMoveUpKey 		= KeyCode.None;		 
		currentKeyboardMoveDownKey 		= KeyCode.None;	 
		currentKeyboardAbility1Key 		= KeyCode.None;
		currentKeyboardAbility2Key 		= KeyCode.None;
		currentKeyboardAbility3Key	 	= KeyCode.None;
		currentKeyboardAbility4Key 		= KeyCode.None;


		currentControllerMoveXAxis		= controller2MoveXAxis;
		currentControllerMoveYAxis		= controller2MoveYAxis;
		currentControllerAbility1 		= controller2Ability1;
		currentControllerAbility2 		= controller2Ability2;
		currentControllerAbility3 		= controller2Ability3;
		currentControllerAbility4 		= controller2Ability4;
	}

	void SetAsController3()
	{
		currentKeyboardMoveLeftKey 		= KeyCode.None;		 
		currentKeyboardMoveRightKey 	= KeyCode.None;	 
		currentKeyboardMoveUpKey 		= KeyCode.None;		 
		currentKeyboardMoveDownKey 		= KeyCode.None;	 
		currentKeyboardAbility1Key 		= KeyCode.None;
		currentKeyboardAbility2Key 		= KeyCode.None;
		currentKeyboardAbility3Key	 	= KeyCode.None;
		currentKeyboardAbility4Key 		= KeyCode.None;


		currentControllerMoveXAxis		= controller3MoveXAxis;
		currentControllerMoveYAxis		= controller3MoveYAxis;
		currentControllerAbility1 		= controller3Ability1;
		currentControllerAbility2 		= controller3Ability2;
		currentControllerAbility3 		= controller3Ability3;
		currentControllerAbility4 		= controller3Ability4;
	}

	void SetAsController4()
	{
		currentKeyboardMoveLeftKey 		= KeyCode.None;		 
		currentKeyboardMoveRightKey 	= KeyCode.None;	 
		currentKeyboardMoveUpKey 		= KeyCode.None;		 
		currentKeyboardMoveDownKey 		= KeyCode.None;	 
		currentKeyboardAbility1Key 		= KeyCode.None;
		currentKeyboardAbility2Key 		= KeyCode.None;
		currentKeyboardAbility3Key	 	= KeyCode.None;
		currentKeyboardAbility4Key 		= KeyCode.None;


		currentControllerMoveXAxis		= controller4MoveXAxis;
		currentControllerMoveYAxis		= controller4MoveYAxis;
		currentControllerAbility1 		= controller4Ability1;
		currentControllerAbility2 		= controller4Ability2;
		currentControllerAbility3 		= controller4Ability3;
		currentControllerAbility4 		= controller4Ability4;
	}

	#endregion
}
