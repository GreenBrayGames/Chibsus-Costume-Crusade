﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//This Script is to get the current tile an object is on top of.
//It needs to go on an empty game object with the smallest circle
//trigger  collider as possible (0.0001) and when its trigger
//enters a new tile that tile number is put into a vector2
public class CurrentTileScript : MonoBehaviour {

	private Vector2 currentTile;

	// Use this for initialization
	void Start () {
		GetCurrentTile ();
	}
	
	// Update is called once per frame
	void Update () {
		GetCurrentTile ();
	}

	void GetCurrentTile()
	{
		RaycastHit2D hit = Physics2D.Linecast (this.transform.position, this.transform.position, 1 << LayerMask.NameToLayer("Tile"));
		if (hit.collider.gameObject.GetComponent<TileScript> () != null)
		{
			currentTile = hit.collider.gameObject.GetComponent<TileScript> ().GetTileNumber ();
			//Debug.Log ("New Tile: " + currentTile);
		}
	}

	GameObject GetTileObjectByPosition(Vector3 pos)
	{
		RaycastHit2D hit = Physics2D.Linecast (pos, pos, 1 << LayerMask.NameToLayer("Tile"));
		if (hit.collider.gameObject.GetComponent<TileScript> () != null)
		{
			return hit.collider.gameObject;
			//Debug.Log ("New Tile: " + currentTile);
		}

		return null;
	}

	public Vector2 ReturnCurrentTile()
	{
		return currentTile;
	}
}
