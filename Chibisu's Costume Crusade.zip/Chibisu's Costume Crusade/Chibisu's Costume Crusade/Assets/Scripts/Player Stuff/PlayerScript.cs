using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour {

	public GlobalEnum.PlayerControllerType controllerType;

	public SpriteRenderer playerImage;
	public Sprite healthImage;
	public bool isBeingPlayed = true;

	//movement clockwise
	//0 = back/up
	//1 = right
	//1 = front/down
	//3 = left
	public RuntimeAnimatorController[] animationControllers = new RuntimeAnimatorController[4];

	public const int maxHealth = 5;
	private int currentHealth = maxHealth;
	public int playerNum = 0;
	private Vector3 startingPosition;

	//immunity stuff
	private bool isImmune = false;
	private float totalImmuneTime = 1.5f;
	private float currentImmuneTime = 0.0f;
	private float alphaChange = 0.075f;
	private float minAlpha = 0.25f;
	private int alphaChangeDirection = -1; // use position numbers (including 0) to go up & negative numbers to go down
	private Vector2 currentTile = Vector2.zero;

	// Use this for initialization
	void Start () {
		startingPosition = this.transform.position;
		currentHealth = maxHealth;
		currentTile = this.gameObject.GetComponent<CurrentTileScript> ().ReturnCurrentTile ();
		this.transform.position = startingPosition;

		//ResetPlayer ();
	}
	
	// Update is called once per frame
	void Update () {
		ChangeAnimator ();
		currentTile = this.gameObject.GetComponent<CurrentTileScript> ().ReturnCurrentTile ();
	} 

	void FixedUpdate () {
		ImmuneAnimation ();
	}

	void ImmuneAnimation()
	{
		if (isImmune) {
			if (currentImmuneTime < totalImmuneTime) {
				currentImmuneTime += Time.fixedDeltaTime;
				if (alphaChangeDirection < 0) {
					//Debug.Log("ALPHA GOING DOWN CURRENT: " + this.gameObject.GetComponent<SpriteRenderer> ().color.a);
					Color newColor = new Color (this.gameObject.GetComponent<SpriteRenderer> ().color.r, 
				                            this.gameObject.GetComponent<SpriteRenderer> ().color.g, 
				                            this.gameObject.GetComponent<SpriteRenderer> ().color.b,
				                            this.gameObject.GetComponent<SpriteRenderer> ().color.a - alphaChange);
					this.gameObject.GetComponent<SpriteRenderer> ().color = newColor;
					if (this.gameObject.GetComponent<SpriteRenderer> ().color.a <= minAlpha) {
						alphaChangeDirection = 1;
					}
				} else {
					//Debug.Log("ALPHA GOING UP CURRENT: " + this.gameObject.GetComponent<SpriteRenderer> ().color.a);
					Color newColor = new Color (this.gameObject.GetComponent<SpriteRenderer> ().color.r, 
					                            this.gameObject.GetComponent<SpriteRenderer> ().color.g, 
					                            this.gameObject.GetComponent<SpriteRenderer> ().color.b,
					                            this.gameObject.GetComponent<SpriteRenderer> ().color.a + alphaChange);
					this.gameObject.GetComponent<SpriteRenderer> ().color = newColor;
					if (this.gameObject.GetComponent<SpriteRenderer> ().color.a >= 1.0f) {
						alphaChangeDirection = -1;
					}
				}
			} else {
				currentImmuneTime = 0.0f;
				isImmune = false;
			}
		} else {
			Color newColor = new Color (this.gameObject.GetComponent<SpriteRenderer> ().color.r, 
			                            this.gameObject.GetComponent<SpriteRenderer> ().color.g, 
			                            this.gameObject.GetComponent<SpriteRenderer> ().color.b,
			                            1.0f);
			this.gameObject.GetComponent<SpriteRenderer> ().color = newColor;
		}
	}

	#region Collision

	void OnCollisionEnter2D(Collision2D col)
	{

	}

	void OnTriggerEnter2D(Collider2D col)
	{

	}
	#endregion

	#region Health Functions
	void TakeDamage(){
		currentHealth--;
		isImmune = true;
	}
	
	public bool IsDead()
	{
		return currentHealth <= 0;
	}
		
	public int GetCurrentHealth ()
	{
		return currentHealth;
	}
	#endregion

	#region Reset Functions
	public void ResetThisAsStartingPosition ()
	{
		startingPosition = this.transform.position;
	}

	public void ResetPlayer()
	{
		currentHealth = maxHealth;
		this.transform.position = startingPosition;
		isImmune = true;

	}
	#endregion

	void ChangeAnimator()
	{
		string s = this.GetComponent<ControllerProfileScript> ().GetCurrentDirection ();

		if(s == "u")
		{
			this.GetComponent<Animator>().runtimeAnimatorController = animationControllers [0];
			this.GetComponent<Animator> ().enabled = true;
		}
		if(s == "r")
		{
			this.GetComponent<Animator>().runtimeAnimatorController = animationControllers [1];
			this.GetComponent<Animator> ().enabled = true;
		}
		if(s == "d")
		{
			this.GetComponent<Animator>().runtimeAnimatorController = animationControllers [2];
			this.GetComponent<Animator> ().enabled = true;
		}
		if(s == "l")
		{
			this.GetComponent<Animator>().runtimeAnimatorController = animationControllers [3];
			this.GetComponent<Animator> ().enabled = true;
		}
		if(s == "n")
		{
			//this.GetComponent<Animator> ().Play("same state you are", -1, 0f);
		}
	}
}