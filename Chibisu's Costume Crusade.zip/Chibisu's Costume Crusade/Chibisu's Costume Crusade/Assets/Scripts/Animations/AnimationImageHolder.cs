﻿using UnityEngine;
using System.Collections;

public class AnimationImageHolder : MonoBehaviour {

	//public
	public Sprite[] frames;
	public bool isPlaying = false;
	public int FPS;

	//private
	private float currentAnimateTime = 0;
	private float timeBetweenFrames;
	private int currentFrameArrayNumber = 0;
	private Sprite currentSprite;
	private SpriteRenderer objectsSpriteRenderer;

	#region StartNUpdates

	void Start()
	{
		objectsSpriteRenderer = this.gameObject.GetComponent<SpriteRenderer> ();
		currentSprite = GetFrameByNumber(currentFrameArrayNumber);
		objectsSpriteRenderer.sprite = currentSprite;
	}
		
	void Update()
	{
		if (isPlaying)
		{
			timeBetweenFrames = 60 / FPS;
			currentAnimateTime += Time.deltaTime;
			if (currentAnimateTime >= timeBetweenFrames)
			{
				currentFrameArrayNumber++;

				if(currentFrameArrayNumber >= frames.Length) 
				{
					currentFrameArrayNumber = 0;
				}

				currentSprite = GetFrameByNumber(currentFrameArrayNumber);
			}
		} 
		else 
		{
			currentFrameArrayNumber = 1;
			currentSprite = GetFrameByNumber(currentFrameArrayNumber);
		}
		objectsSpriteRenderer.sprite = currentSprite;
	}

	#endregion

	#region Getters

	public Sprite GetFrameByNumber(int num)
	{
		return frames [num];
	}

	#endregion

}
